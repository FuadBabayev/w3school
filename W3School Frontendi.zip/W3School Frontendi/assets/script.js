$(document).ready(function(){
    $("li.html").click(function(){
        $("div.list-html").slideToggle(1500).css({
            color: 'black',
            })
});
});

$(document).ready(function(){
    $("i#hamburger").click(function(){
        $("ul.nav-li").slideToggle(1500);
    });
});